package edu.davenport.cisp340.converter;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class Converter extends AppCompatActivity {

    Button btn1;
    EditText etxt1;
    EditText etxt2;
    EditText etxt3;
    TextView txtvw;
    String message;
    private Button alertButton;
    private TextView alertTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter);
        btn1 = (Button)findViewById(R.id.button);
        etxt1 = (EditText)findViewById(R.id.editText);
        etxt2 = (EditText)findViewById(R.id.editText2);
        etxt3 = (EditText)findViewById(R.id.editText3);
        txtvw = (TextView)findViewById(R.id.textView);
        btn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                //gets user input for knots and converts to a double
                String knots = etxt1.getText().toString();
                int new_knots = Integer.parseInt(knots);
                double knotConversion = (new_knots * 1.151);

                //gets user input for nautical miles and converts to a double
                String nautical_miles = etxt2.getText().toString();
                int miles = Integer.parseInt(nautical_miles);
                double mileConversion = (miles * 1.151);

                // gets user input for compass heading and converts it to an int
                String heading = etxt3.getText().toString();
                int newHeading = Integer.parseInt(heading);
                //int headingConversion = (newHeading + 180);
                int headingConversion=0;
                if(newHeading > 180 && newHeading < 360) {
                    headingConversion = (newHeading - 180);
                    //won't register if number is going to be greater than 180
                    message = String.format(" %.2f\n %.2f", knotConversion, mileConversion)+(
                            "\n "+headingConversion);
                    txtvw.setText(message);
                }
                else if(newHeading < 180){
                    headingConversion = (newHeading + 180);
                    message = String.format(" %.2f\n %.2f", knotConversion, mileConversion)+(
                            "\n"+headingConversion );
                    txtvw.setText(message);
                }
                else{
                    message = String.format(" %.2f\n %.2f\n%d > 360",knotConversion, mileConversion, newHeading);
                    txtvw.setText(message);
                }
                //message = String.format("The miles per an hour are: %.2f\nThe statute miles are: %.2f", knotConversion, mileConversion)+(
                //      "\nThe reciprocal heading is: "+headingConversion);

                //set string to the textView
                // txtvw.setText(message);
                Button reset = (Button) findViewById(R.id.button_clear);

                reset.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        etxt1.getText().clear();
                        etxt2.getText().clear();
                        etxt3.getText().clear();

                    }
                });


            }

        });
        alertButton = (Button) findViewById(R.id.AlertButton);
        alertTextView = (TextView) findViewById(R.id.AlertTextView);

        alertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Converter.this);

                builder.setCancelable(true);
                builder.setTitle("About Us");
                builder.setMessage("We converter measurements and dirction headings for ship navigators.");

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        dialogInterface.cancel();
                    }
                });
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertTextView.setVisibility(View.VISIBLE);
                    }
                });
                builder.show();
            }
        });
    }


}
